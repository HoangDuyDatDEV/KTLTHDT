/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP.KhaibaoLopThiSinh;

/**
 *
 * @author dathd-8970
 */
public class thisinh {
    
}
